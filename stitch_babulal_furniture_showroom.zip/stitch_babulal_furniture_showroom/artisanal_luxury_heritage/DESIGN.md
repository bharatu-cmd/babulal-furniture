---
name: Artisanal Luxury Heritage
colors:
  surface: '#fcf9f4'
  surface-dim: '#dcdad5'
  surface-bright: '#fcf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ee'
  surface-container: '#f0ede9'
  surface-container-high: '#ebe8e3'
  surface-container-highest: '#e5e2dd'
  on-surface: '#1c1c19'
  on-surface-variant: '#4b463f'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f3f0eb'
  outline: '#7c766e'
  outline-variant: '#cdc5bc'
  surface-tint: '#615e5a'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1d1b18'
  on-primary-container: '#87837f'
  inverse-primary: '#cbc5c0'
  secondary: '#725949'
  on-secondary: '#ffffff'
  secondary-container: '#fcd9c5'
  on-secondary-container: '#775d4d'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#261900'
  on-tertiary-container: '#a17f3b'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e7e1dc'
  primary-fixed-dim: '#cbc5c0'
  on-primary-fixed: '#1d1b18'
  on-primary-fixed-variant: '#494643'
  secondary-fixed: '#fedcc8'
  secondary-fixed-dim: '#e1c0ad'
  on-secondary-fixed: '#29170b'
  on-secondary-fixed-variant: '#594233'
  tertiary-fixed: '#ffdea5'
  tertiary-fixed-dim: '#e9c176'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5d4201'
  background: '#fcf9f4'
  on-background: '#1c1c19'
  surface-variant: '#e5e2dd'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '600'
    lineHeight: 68px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '500'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.14em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 2rem
  gutter-mobile: 1rem
  margin: 4rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
---

## Brand & Style

This design system embodies the confluence of generational Indian timber craftsmanship and quiet contemporary minimalism. The aesthetic speaks to discerning homeowners, interior architects, and design connoisseurs seeking heirloom-grade solid wood furniture.

The visual style is rooted in **Warm Editorial Tactility**:
- **Generous Restraint:** Substantial negative space permits grain, proportion, and texture to command attention without visual noise.
- **Architectural Poise:** Crisp grid structures inspired by modernist architecture frame organic wooden silhouettes.
- **Craft Touchpoints:** Subtle hairline dividers, unhurried typography, and warm tactile micro-interactions recreate the sensory gravitas of raw teak, hand-rubbed wax, and brushed brass joinery.
- **Immediate Accessibility:** Balanced with frictionless conversational pathways (e.g., dedicated WhatsApp inquiry integrations) tailored for high-trust, bespoke consultations.

## Colors

The palette draws directly from artisanal woodworking ateliers—raw timber, aged joinery, burnished hardware, and natural light spilling across lime-washed studio walls.

### Primary Darks
- **Deep Charcoal (`#1C1A17`):** The foundational tone for primary actions, critical headlines, and architectural framing. Offers superior warmth and softness compared to pure obsidian.
- **Rich Walnut (`#3B271A`):** The secondary anchor used for secondary surfaces, hovering states, footer structures, and refined metadata labels.

### Accents & Warmth
- **Brushed Gold / Muted Brass (`#C5A059`):** Reserved for delicate craftsmanship accents, active states, certification insignias, customisation indicators, and curated highlights. Never overused; functions like bespoke metal hardware on solid wood cabinetry.
- **Natural Teak (`#8C5835`):** Serves as an expressive ambient tint for badges, subtle material tags, and active pagination pips.

### Canvas & Surfaces
- **Warm Cream (`#FAF7F2`):** Primary canvas background, delivering a restful, tactile editorial mood far gentler than clinical stark white.
- **Ivory Tint (`#F4EFEB`):** Layered surface for nested cards, interactive panels, table strips, and container wells.
- **Border Ochre / Hairline (`#E8DFD5`):** The delicate, low-contrast boundary line for cards and grid dividers.

## Typography

The typography couples the graceful, high-contrast serif cadence of Playfair Display with the geometric, human-centric legibility of Plus Jakarta Sans.

- **Editorial Headlines (`Playfair Display`):** Reserved for brand moments, collection hero sections, editorial quotes, and bespoke collection titles. It brings literary dignity, evoking architectural coffee-table monographs.
- **Airy Precision (`Plus Jakarta Sans`):** Carries product specifications, dimensions, material narratives, pricing, and operational UI. Its wide counters and crisp apertures prevent reading fatigue during prolonged browsing.
- **Craft Hierarchy (`label-caps`):** Rendered in uppercase with generous tracking (`0.14em`) for material origin markers, dimension categories, wood species labels (e.g., "RECLAIMED TEAKWOOD", "AGED BRASS"), and collection breadcrumbs.

## Layout & Spacing

A disciplined, 12-column architectural grid establishes rhythm across all viewport tiers:

- **Desktop (1200px+):** 12 columns with `2rem` (32px) gutters and `4rem` (64px) canvas outer margins. Max content container is capped at 1440px to preserve comfortable line length and proportion.
- **Tablet (768px - 1199px):** 8 columns with `1.5rem` (24px) gutters and `2.5rem` (40px) outer margins.
- **Mobile (Below 768px):** 4 columns with `1rem` (16px) gutters and `1.25rem` (20px) margins.

### Spatial Rhythm
Furniture displays demand breathing room. Product cards never crowd the edge of their bounding boxes. Section verticals employ staggered spacing (using multiples of `space-xl` up to 6rem/96px on desktop) to demarcate transitions between technical specs, room mockups, and heritage storytelling.

## Elevation & Depth

This design system rejects deep artificial drop shadows in favor of **Tonal Layering** combined with **Ambient Soft Umber Diffusion**:

- **Subtle Grounding (Level 1):** `0 2px 8px -2px rgba(28, 26, 23, 0.04), 0 1px 3px -1px rgba(28, 26, 23, 0.03)`. Used for resting cards and navigation headers.
- **Floating Hover (Level 2):** `0 12px 28px -6px rgba(59, 39, 26, 0.08), 0 4px 12px -2px rgba(59, 39, 26, 0.04)`. Imbued with a tiny amber/walnut tint to mimic warm directional sunlit shadow rather than cold digital grey.
- **Overlays & Drawers (Level 3):** `0 24px 48px -12px rgba(28, 26, 23, 0.16)`. Combined with a backdrop blur (`backdrop-filter: blur(8px)`) over a tinted semi-transparent veil (`rgba(250, 247, 242, 0.82)`).
- **Hairline Framing:** Depth is primarily delineated by precise `1px` borders in `#E8DFD5` rather than high-contrast cast shadows, reinforcing an architectural blueprint quality.

## Shapes

The design system adopts a **Soft (Level 1)** geometric standard (`0.25rem` / 4px base radius, scaling to `0.5rem` / 8px on larger surfaces).

- **Architectural Edge:** Sharp corners feel clinical, whereas excessively rounded bubbles undermine the substantial weight of solid wood furniture. Subtle 4px softening mimics the gently eased, hand-sanded edges of artisanal hardwood joints.
- **Pill Exception:** Chips, filter tags, and bespoke contextual CTA pills (e.g., the direct WhatsApp concierge action) use complete round pill ends (`9999px`) to immediately convey actionable touch points without disturbing the geometric discipline of catalog cards and architectural images.

## Components

### Buttons
- **Primary:** Background in Deep Charcoal (`#1C1A17`), label in Warm Cream (`#FAF7F2`), subtle transition to Rich Walnut (`#3B271A`) on hover. Height is 48px with generous horizontal padding (28px) and tracking.
- **Secondary / Ghost:** Transparent background enclosed by a 1px border in `#1C1A17`. Text in `#1C1A17`. Hover fills with Ivory (`#F4EFEB`).
- **Brass Accent (Craft / Bespoke):** Muted Brass (`#C5A059`) fill with Deep Charcoal text for highlight collection launches or custom commission requests.
- **WhatsApp Concierge Action:** Specialized sticky or card-level button featuring a rich emerald tint (`#1A5336`) or Deep Charcoal pairing with gold accent iconography, optimized for fast mobile quotation and wood swatch requests.

### Cards (Product & Editorial)
- **Product Card:** Placed on Ivory (`#F4EFEB`) or transparent Warm Cream ground, framed by a soft hairline border (`#E8DFD5`). Ratio is predominantly 4:5 or 3:4 portrait to respect vertical wood grains. Displays wood finish tags, finish variant dots, pricing, and an unobtrusive quick-inquire trigger.
- **Craft Story Card:** Blends photography and typography seamlessly with generous padding (`space-lg`), highlighting artisan techniques, wood seasoning, and traditional joinery methods.

### Chips & Filter Tags
- **Default:** Transparent with hairline border `#E8DFD5`, text in Rich Walnut (`#3B271A`).
- **Active:** Deep Charcoal (`#1C1A17`) background with Warm Cream text.
- **Wood Species Indicator:** Compact chip featuring an integrated circular thumbnail swatch (e.g., Teak, Sheesham, Walnut) accompanied by an uppercase label.

### Input Fields & Controls
- **Text Inputs:** Ivory (`#F4EFEB`) background, 1px `#D9CEC2` border, 48px height. On focus: border shifts to Rich Walnut (`#3B271A`) with no glaring neon ring. Placeholder text styled in muted warm grey (`#8A827A`).
- **Checkboxes & Radios:** Hand-finished brass look when selected (`#C5A059` fill with Warm Cream tick); unselected states use clean hairline outlines.

### Bespoke Domain Components
- **Dimension & Specification Inspector:** Tabular comparison module featuring millimetre/inch toggles, timber moisture rating indicators, and room clearance guidance.
- **Swatch Selector:** Interactive circular swatches showcasing authentic timber grain, fabric weaves, and brass finishes with real-time viewport updates.
- **Direct WhatsApp Fabric & Swatch Request Strip:** Contextual banner anchored near high-ticket items enabling immediate one-tap routing to dedicated design consultants.